<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use App\Jobs\ImportProductsJob;

class ProductImportTest extends TestCase
{
    use RefreshDatabase;

    public function test_admin_can_queue_import(): void
    {
        Storage::fake('local');
        $file = UploadedFile::fake()->create('products.csv', 10);
        $response = $this->post('/admin/products/import', ['file'=>$file]);
        $response->assertRedirect();
    }
}
