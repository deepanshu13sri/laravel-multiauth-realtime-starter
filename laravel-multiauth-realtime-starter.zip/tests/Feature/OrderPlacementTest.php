<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use App\Models\{Customer, Product};

class OrderPlacementTest extends TestCase
{
    use RefreshDatabase;

    public function test_place_order(): void
    {
        $customer = Customer::factory()->create();
        $product = Product::factory()->create(['price'=>10]);

        $payload = ['items'=>[['product_id'=>$product->id,'qty'=>2]]];
        $this->actingAs($customer, 'customer');
        $res = $this->post('/orders', $payload);
        $res->assertRedirect();
    }
}
