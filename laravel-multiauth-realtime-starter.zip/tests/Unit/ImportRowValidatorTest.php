<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;

class ImportRowValidatorTest extends TestCase
{
    public function test_price_validation(): void
    {
        $row = ['name'=>'X','price'=>'10.5'];
        $this->assertTrue(is_numeric($row['price']));
    }
}
