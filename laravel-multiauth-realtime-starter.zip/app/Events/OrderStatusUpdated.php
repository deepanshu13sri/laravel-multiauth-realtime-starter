<?php

namespace App\Events;

use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Broadcasting\ShouldBroadcast;
use Illuminate\Queue\SerializesModels;

class OrderStatusUpdated implements ShouldBroadcast
{
    use InteractsWithSockets, SerializesModels;

    public function __construct(public int $orderId, public string $status, public int $customerId){}

    public function broadcastOn()
    {
        return new Channel('orders.' . $this->customerId);
    }

    public function broadcastAs(){ return 'OrderStatusUpdated'; }

    public function broadcastWith(){
        return ['order_id'=>$this->orderId, 'status'=>$this->status];
    }
}
