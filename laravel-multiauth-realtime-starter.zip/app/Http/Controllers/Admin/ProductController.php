<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Product;
use App\Jobs\ImportProductsJob;

class ProductController extends Controller
{
    public function index(){ $products = Product::latest()->paginate(15); return view('admin.products.index', compact('products')); }
    public function create(){ return view('admin.products.create'); }
    public function store(Request $r){
        $data = $r->validate([
            'name'=>'required',
            'description'=>'nullable',
            'price'=>'required|numeric',
            'category'=>'nullable',
            'stock'=>'required|integer',
            'image'=>'nullable|image'
        ]);
        if($r->hasFile('image')){
            $data['image'] = $r->file('image')->store('products','public');
        } else {
            $data['image'] = 'defaults/product.png';
        }
        Product::create($data);
        return redirect()->route('products.index')->with('ok','Product created');
    }
    public function edit(Product $product){ return view('admin.products.edit', compact('product')); }
    public function update(Request $r, Product $product){
        $data = $r->validate([
            'name'=>'required',
            'description'=>'nullable',
            'price'=>'required|numeric',
            'category'=>'nullable',
            'stock'=>'required|integer',
            'image'=>'nullable|image'
        ]);
        if($r->hasFile('image')){
            $data['image'] = $r->file('image')->store('products','public');
        }
        $product->update($data);
        return back()->with('ok','Updated');
    }
    public function destroy(Product $product){ $product->delete(); return back()->with('ok','Deleted'); }

    public function import(Request $r){
        $r->validate(['file'=>'required|file|mimes:csv,txt,xlsx,xls']);
        $path = $r->file('file')->store('imports');
        ImportProductsJob::dispatch($path);
        return back()->with('ok','Import queued.');
    }
}
