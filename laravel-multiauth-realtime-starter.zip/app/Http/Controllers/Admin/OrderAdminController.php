<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use Illuminate\Http\Request;
use App\Events\OrderStatusUpdated;
use App\Notifications\OrderStatusPush;

class OrderAdminController extends Controller
{
    public function index(){
        $orders = Order::with('customer','items.product')->latest()->paginate(20);
        return view('admin.orders.index', compact('orders'));
    }

    public function updateStatus(Request $r, Order $order){
        $data = $r->validate(['status'=>'required|in:Pending,Shipped,Delivered']);
        $order->update($data);

        event(new OrderStatusUpdated($order->id, $order->status, $order->customer_id));

        if($order->customer){
            $order->customer->notify(new OrderStatusPush($order));
        }
        return back()->with('ok','Status updated & broadcasted');
    }
}
