<?php

namespace App\Http\Controllers\Admin\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Admin;
use Illuminate\Support\Facades\Hash;

class RegisterController extends Controller
{
    public function showRegister(){ return view('admin.auth.register'); }
    public function register(Request $r){
        $data = $r->validate([
            'name'=>'required',
            'email'=>'required|email|unique:admins,email',
            'password'=>'required|min:6|confirmed'
        ]);
        $data['password'] = Hash::make($data['password']);
        Admin::create($data);
        return redirect()->route('admin.login')->with('ok','Admin registered.');
    }
}
