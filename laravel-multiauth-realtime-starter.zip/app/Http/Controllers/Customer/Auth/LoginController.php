<?php

namespace App\Http\Controllers\Customer\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    public function showLogin(){ return view('customer.auth.login'); }
    public function login(Request $r){
        $cred = $r->validate(['email'=>'required|email','password'=>'required']);
        if(Auth::guard('customer')->attempt($cred, $r->boolean('remember'))){
            $r->session()->regenerate();
            return redirect()->intended(route('customer.dashboard'));
        }
        return back()->withErrors(['email'=>'Invalid credentials']);
    }
}
