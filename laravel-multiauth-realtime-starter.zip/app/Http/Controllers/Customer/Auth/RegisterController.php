<?php

namespace App\Http\Controllers\Customer\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Customer;
use Illuminate\Support\Facades\Hash;

class RegisterController extends Controller
{
    public function showRegister(){ return view('customer.auth.register'); }
    public function register(Request $r){
        $data = $r->validate([
            'name'=>'required',
            'email'=>'required|email|unique:customers,email',
            'password'=>'required|min:6|confirmed'
        ]);
        $data['password'] = Hash::make($data['password']);
        Customer::create($data);
        return redirect()->route('customer.login')->with('ok','Account created.');
    }
}
