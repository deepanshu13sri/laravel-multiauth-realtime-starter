<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\{Product, Order, OrderItem};
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class OrderController extends Controller
{
    public function shop(Request $r){
        $q = Product::query();
        if($s = $r->get('s')){ $q->where('name','like',"%{$s}%"); }
        $products = $q->paginate(20);
        return view('customer.shop', compact('products'));
    }

    public function place(Request $r){
        $data = $r->validate(['items'=>'required|array','items.*.product_id'=>'required|exists:products,id','items.*.qty'=>'required|integer|min:1']);
        $customerId = Auth::guard('customer')->id();
        $total = 0;

        DB::transaction(function() use ($data, $customerId, &$total){
            $order = Order::create(['customer_id'=>$customerId, 'status'=>'Pending', 'total'=>0]);
            foreach($data['items'] as $it){
                $product = Product::findOrFail($it['product_id']);
                $qty = $it['qty'];
                $price = $product->price;
                OrderItem::create(['order_id'=>$order->id,'product_id'=>$product->id,'qty'=>$qty,'price'=>$price]);
                $total += $qty * $price;
            }
            $order->update(['total'=>$total]);
        });

        return back()->with('ok','Order placed');
    }
}
