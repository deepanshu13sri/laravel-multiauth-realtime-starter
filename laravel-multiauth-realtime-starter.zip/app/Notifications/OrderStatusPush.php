<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use NotificationChannels\OneSignal\OneSignalChannel;
use NotificationChannels\OneSignal\OneSignalMessage;
use App\Models\Order;

class OrderStatusPush extends Notification
{
    use Queueable;

    public function __construct(public Order $order){}

    public function via($notifiable)
    {
        return [OneSignalChannel::class];
    }

    public function toOneSignal($notifiable)
    {
        return OneSignalMessage::create()
            ->setSubject('Order status updated')
            ->setBody('Your order #' . $this->order->id . ' is now ' . $this->order->status);
    }
}
