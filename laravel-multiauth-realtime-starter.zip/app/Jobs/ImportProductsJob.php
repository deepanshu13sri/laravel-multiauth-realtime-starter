<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use App\Models\Product;
use Illuminate\Support\Facades\Storage;

class ImportProductsJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $timeout = 1200; // 20 min

    public function __construct(public string $path){}

    public function handle(): void
    {
        $stream = Storage::readStream($this->path);
        if(!$stream){ return; }
        $header = null;
        $defaultImage = 'defaults/product.png';
        $batch = [];
        $batchSize = 1000;

        while(($row = fgetcsv($stream)) !== false){
            if(!$header){ $header = $row; continue; }
            $data = array_combine($header, $row);

            // basic validation
            if(empty($data['name']) || !is_numeric($data['price'])){ continue; }

            $batch[] = [
                'name' => $data['name'],
                'description' => $data['description'] ?? null,
                'price' => (float)$data['price'],
                'image' => $data['image'] ?: $defaultImage,
                'category' => $data['category'] ?? null,
                'stock' => (int)($data['stock'] ?? 0),
                'created_at' => now(),
                'updated_at' => now(),
            ];

            if(count($batch) >= $batchSize){
                Product::insert($batch);
                $batch = [];
            }
        }
        if($batch){ Product::insert($batch); }
    }
}
