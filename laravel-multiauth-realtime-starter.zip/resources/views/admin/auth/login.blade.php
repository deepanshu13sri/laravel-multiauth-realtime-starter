<form method="post" action="/admin/login">
    <?php echo csrf_field(); ?>
    <input name="email" placeholder="Email">
    <input name="password" placeholder="Password" type="password">
    <button type="submit">Login</button>
</form>
<a href="/admin/register">Register</a>
