<form method="post" action="/admin/register">
    <?php echo csrf_field(); ?>
    <input name="name" placeholder="Name">
    <input name="email" placeholder="Email">
    <input name="password" placeholder="Password" type="password">
    <input name="password_confirmation" placeholder="Confirm" type="password">
    <button type="submit">Register</button>
</form>
