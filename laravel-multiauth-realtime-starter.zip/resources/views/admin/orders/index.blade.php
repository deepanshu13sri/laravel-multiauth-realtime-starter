<h2>Orders</h2>
<table border="1">
<tr><th>ID</th><th>Customer</th><th>Status</th><th>Total</th><th>Change</th></tr>
<?php foreach($orders as $o): ?>
<tr>
<td><?= $o->id ?></td><td><?= $o->customer?->name ?></td><td><?= $o->status ?></td><td><?= $o->total ?></td>
<td>
<form method="post" action="/admin/orders/<?= $o->id ?>/status">
<?php echo csrf_field(); echo method_field('PATCH'); ?>
<select name="status">
<option <?= $o->status==='Pending'?'selected':'' ?>>Pending</option>
<option <?= $o->status==='Shipped'?'selected':'' ?>>Shipped</option>
<option <?= $o->status==='Delivered'?'selected':'' ?>>Delivered</option>
</select>
<button>Update</button>
</form>
</td>
</tr>
<?php endforeach; ?>
</table>
<?= $orders->links() ?>
