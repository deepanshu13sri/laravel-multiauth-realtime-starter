<form method="post" action="/admin/products" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input name="name" placeholder="Name">
    <textarea name="description" placeholder="Description"></textarea>
    <input name="price" placeholder="Price" type="number" step="0.01">
    <input name="category" placeholder="Category">
    <input name="stock" placeholder="Stock" type="number">
    <input type="file" name="image">
    <button type="submit">Save</button>
</form>
