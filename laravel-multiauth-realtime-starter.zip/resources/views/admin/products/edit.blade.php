<form method="post" action="/admin/products/{{ $product->id }}" enctype="multipart/form-data">
    <?php echo method_field('PUT'); echo csrf_field(); ?>
    <input name="name" value="{{ $product->name }}">
    <textarea name="description">{{ $product->description }}</textarea>
    <input name="price" value="{{ $product->price }}" type="number" step="0.01">
    <input name="category" value="{{ $product->category }}">
    <input name="stock" value="{{ $product->stock }}" type="number">
    <input type="file" name="image">
    <button type="submit">Update</button>
</form>
