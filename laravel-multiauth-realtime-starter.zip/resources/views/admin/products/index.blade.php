<h2>Products</h2>
<a href="/admin/products/create">Create</a>
<form method="post" action="/admin/products/import" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="file" name="file">
    <button type="submit">Import (CSV/Excel)</button>
</form>
<table border="1">
<tr><th>ID</th><th>Name</th><th>Price</th><th>Stock</th><th>Actions</th></tr>
<?php foreach($products as $p): ?>
<tr>
<td><?= $p->id ?></td><td><?= $p->name ?></td><td><?= $p->price ?></td><td><?= $p->stock ?></td>
<td><a href="/admin/products/<?= $p->id ?>/edit">Edit</a></td>
</tr>
<?php endforeach; ?>
</table>
<?= $products->links() ?>
