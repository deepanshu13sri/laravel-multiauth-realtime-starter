<h2>Admin Dashboard</h2>
<p><a href="/admin/products">Manage Products</a> | <a href="/admin/orders">Orders</a></p>
<div id="presence">Presence channel: presence-online</div>
