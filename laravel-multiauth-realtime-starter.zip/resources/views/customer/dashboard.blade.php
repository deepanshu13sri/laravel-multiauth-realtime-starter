<h2>Customer Dashboard</h2>
<p><a href="/shop">Shop</a></p>
<div id="realtime">Order updates will appear here via Echo.</div>
