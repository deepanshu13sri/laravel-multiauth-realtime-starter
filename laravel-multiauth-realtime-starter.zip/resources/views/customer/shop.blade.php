<h2>Shop</h2>
<form>
    <input name="s" value="{{ request('s') }}" placeholder="Search products">
    <button>Search</button>
</form>
<form method="post" action="/orders">
<?php echo csrf_field(); ?>
<table border="1">
<tr><th>Select</th><th>Name</th><th>Price</th><th>Qty</th></tr>
<?php foreach($products as $p): ?>
<tr>
<td><input type="checkbox" name="items[<?= $p->id ?>][product_id]" value="<?= $p->id ?>"></td>
<td><?= $p->name ?></td><td><?= $p->price ?></td>
<td><input type="number" name="items[<?= $p->id ?>][qty]" value="1" min="1"></td>
</tr>
<?php endforeach; ?>
</table>
<button>Place Order</button>
</form>
<?= $products->links() ?>
