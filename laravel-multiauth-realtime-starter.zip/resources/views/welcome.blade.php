<!doctype html>
<html>
<head><meta charset="utf-8"><title>Laravel Realtime Starter</title></head>
<body>
<h1>Laravel Realtime Starter</h1>
<p><a href="/admin/login">Admin Login</a> | <a href="/login">Customer Login</a></p>
</body>
</html>
