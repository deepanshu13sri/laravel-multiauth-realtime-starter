<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\Auth\LoginController as AdminLogin;
use App\Http\Controllers\Admin\Auth\RegisterController as AdminRegister;
use App\Http\Controllers\Customer\Auth\LoginController as CustomerLogin;
use App\Http\Controllers\Customer\Auth\RegisterController as CustomerRegister;
use App\Http\Controllers\Admin\ProductController;
use App\Http\Controllers\Admin\OrderAdminController;
use App\Http\Controllers\Customer\OrderController as CustomerOrderController;

Route::get('/', function(){ return view('welcome'); });

// Admin auth
Route::get('/admin/login', [AdminLogin::class, 'showLogin'])->name('admin.login');
Route::post('/admin/login', [AdminLogin::class, 'login']);
Route::get('/admin/register', [AdminRegister::class, 'showRegister'])->name('admin.register');
Route::post('/admin/register', [AdminRegister::class, 'register']);

Route::middleware('auth:admin')->prefix('admin')->group(function(){
    Route::view('/dashboard', 'admin.dashboard')->name('admin.dashboard');
    Route::resource('/products', ProductController::class);
    Route::post('/products/import', [ProductController::class, 'import'])->name('products.import');
    Route::get('/orders', [OrderAdminController::class, 'index'])->name('admin.orders.index');
    Route::patch('/orders/{order}/status', [OrderAdminController::class, 'updateStatus'])->name('admin.orders.status');
});

// Customer auth
Route::get('/login', [CustomerLogin::class, 'showLogin'])->name('customer.login');
Route::post('/login', [CustomerLogin::class, 'login']);
Route::get('/register', [CustomerRegister::class, 'showRegister'])->name('customer.register');
Route::post('/register', [CustomerRegister::class, 'register']);

Route::middleware('auth:customer')->group(function(){
    Route::view('/dashboard', 'customer.dashboard')->name('customer.dashboard');
    Route::get('/shop', [CustomerOrderController::class, 'shop'])->name('shop');
    Route::post('/orders', [CustomerOrderController::class, 'place'])->name('orders.place');
});

