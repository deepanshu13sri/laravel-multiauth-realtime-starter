<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(){
        Schema::create('user_presences', function(Blueprint $t){
            $t->id();
            $t->string('user_type'); // Admin or Customer
            $t->unsignedBigInteger('user_id');
            $t->string('status')->default('offline'); // online/offline
            $t->timestamps();
            $t->index(['user_type','user_id']);
        });
    }
    public function down(){ Schema::dropIfExists('user_presences'); }
};
